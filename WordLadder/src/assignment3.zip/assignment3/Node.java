package assignment3;

public class Node {
	public String word; 
	public Node prev; 
	
	public Node(String word, Node prev) {
		this.word = word; 
		this.prev = prev; 
	}

}
